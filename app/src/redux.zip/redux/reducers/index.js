import { combineReducers } from 'redux'
import doctor from './doctor'

const rootReducer = combineReducers({
	doctor
})

export default rootReducer